# givejobpls_patch

This is the root of the givejobpls_patch package.
