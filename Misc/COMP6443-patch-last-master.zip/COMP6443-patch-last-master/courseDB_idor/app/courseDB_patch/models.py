#!/usr/bin/env python3

# models.py
#
# Used for sqlalchemy style models
