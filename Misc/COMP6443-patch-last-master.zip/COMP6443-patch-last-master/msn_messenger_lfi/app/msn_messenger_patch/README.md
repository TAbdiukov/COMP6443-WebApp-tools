# msn_messenger_patch

This is the root of the msn_messenger_patch package.
