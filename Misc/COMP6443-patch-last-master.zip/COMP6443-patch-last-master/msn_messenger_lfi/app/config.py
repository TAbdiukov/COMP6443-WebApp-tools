TITLE = "msn messenger"

FLAG_IDS = "DUMMY"
FLAG_WRAP = "DUMMY"
FLAG_SECRET = "DUMMY"
DB_CONNECTION_STRING = "postgresql://dummy/dummy"

ENABLE_AUTH = False
AUTO_GENERATED_FLAGS = False
